#Stampare ogni carattere della stringa
nome_scuola = 'Epicode'
n = 0
while n <len(nome_scuola):
    print(nome_scuola[n])
    n+=1
