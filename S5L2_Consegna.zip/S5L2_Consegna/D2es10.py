#lista guadagni
guadagni = [100, 90, 70, 40, 50, 80, 90, 120, 80, 20, 50, 50]
n=0
somma = 0
while n<len(guadagni):
    somma += guadagni[n]
    n+=1
print('media dei guadagni è:', somma/len(guadagni))
