#Calcolare e stampare tutte le prime N potenze di 2
n=int(input('insericsci un numero'))
lista = []
while n<=10:
    lista.append(2**n)
    n+=1
print('le prime',n,'potenze di 2 è:', lista)
