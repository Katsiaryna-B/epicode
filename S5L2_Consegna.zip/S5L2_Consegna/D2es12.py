#Stampare a video tutti e soli gli studenti che frequentano una prima edizione
studenti = ["Alex", "Bob", "Cindy", "Dan", "Emma", "Faith", "Grace", "Henry"] 
corsi = ["Cybersecurity", "Data Analyst", "Backend", "Frontend", "Data Analyst", "Backend", "Frontend", "Cybersecurity"] 
edizioni = [1, 2, 3, 2, 2, 1, 3, 3]
k = 0
primaEdizione = []
while k<len(edizioni):
    if edizioni[k] == 1:
        primaEdizione.append(studenti[k])
    k+=1
print(primaEdizione)
