#Stampare a video numeri da 0 a 20
n=0
while n<=20:
    print(n)
    n+=1
