# cambiare il simbolo dell'euro (€) in quello del dollaro ($) per ogni stringa nella lista; il risultato sarà memorizzato in un'altra lista.
prezzi = ["100 €", "200 €", "500 €", "10 €", "50 €", "70 €"]
k=0
prezziCor = []
while k < len(prezzi):
    prezziCor.append((prezzi[k]).replace('€', '$'))
    k+=1
print(prezziCor)
