#Calcolare le prime N potenza di K
k = int(input('Give me a number'))
n = int(input('Give me a power factor'))
a = 0
listaNK = []
while a <= n:
    listaNK.append(k**a)
    a += 1
print(listaNK)    
