#Programma che visualizza i primi 3 e gli ultimi 3 caratteri per le parole con piu di 6 lettere
word = input('Give me a word')
if len(word)>6:
    programma = word[0:3] +'...' +word[-3:]
    print(programma)
elif len(word)<=6:
    print(word)
