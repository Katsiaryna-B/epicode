# trovare il codici che contengono 95, stampare la lista. per ogni CF stampare caratteri asscociati al noome, cognome
lista_cf = ["ABCDEF95G01A123B", "GHIJKL91M02A321C", "MNOPQR89S03A456D", "STUVWX95Z04A654E", "XYZABC01D05A789F", "DEFGHI95J06A987G"]
n = 0
cf95 = []
while n < len(lista_cf):
    if '95' in lista_cf[n]:
        cf95.append(lista_cf[n])
    n += 1
print('CF con 95:',cf95)
k=0
while k<len(cf95):
    print('CF', cf95[k], 'nome:',cf95[k][:3], 'cognome:',cf95[k][3:6])
    k+=1
    
