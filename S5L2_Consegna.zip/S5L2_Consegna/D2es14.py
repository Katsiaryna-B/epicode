#Creiamo due liste per ogni squadra, e alla fine visualizziamole.
studenti = ["Alex", "Bob", "Cindy", "Dan", "Emma", "Faith", "Grace", "Henry", "Isabelle", "John"]
squadra1 = []
squadra2 = []
k=0
while k < len(studenti):
    if k%2 == 0:
        squadra1.append(studenti[k])
    else:
        squadra2.append(studenti[k])
    k +=1
print('squadra1:',squadra1, 'squadra2:', squadra2)
