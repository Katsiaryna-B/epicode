#aggiungere i dati mancanti alla lista corsi: Emma data analyst, Faith Backend, Grace Frontend, Henry Cybersecurity
studenti = ['Alex', 'Bob', 'Cindy', 'Dan', 'Emma', 'Faith', 'Grace', 'Henry']
corsi = ['Cybersecurity', 'Data Analyst', 'Backend', 'Frontend', 'Data Analyst', 'Backend']
n=len(corsi)
while n<len(studenti):
    if studenti[n]=='Emma':
        corsi.append('Data Analyst')
    elif studenti[n]=='Faith':
        corsi.append('Backend')
    elif studenti[n]=='Grace':
        corsi.append('Frontend')
    elif studenti[n]=='Henry':
        corsi.append('Cybersecurity')
    n +=1
if len(corsi) == len(studenti):
    print(corsi)
else:
    print('Fai attenzione')
