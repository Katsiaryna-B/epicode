#Calcolare e stampare tutte le prime potenze di 2
n=2
while n<=10:
    print(2**n)
    n+=1
