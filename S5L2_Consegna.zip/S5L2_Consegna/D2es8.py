#Memorizza e stampa tutti i divisori di un numero
numero= int(input('Give me a number'))
n=1
divisori = []
while n<=numero:
    if numero%n==0:
        divisori.append(n)
    n+=1
print(divisori)
