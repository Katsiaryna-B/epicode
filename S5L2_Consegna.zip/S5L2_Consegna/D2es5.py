#Calcolare e stampare tutte le potenze di 2 minori di 25000
n = 0
potenza = 2 ** n

while potenza < 25000:
    print('2 elevato alla', n, 'potenza è uguale a:', potenza)
    n += 1
    potenza = 2 ** n
